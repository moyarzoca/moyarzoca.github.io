---
title: "Clasificación de Dynkin y Kaluza Klein"
author: "Marcelo Oyarzo"
date: \today
header-includes:
  - \newcommand{\dd}{\mathrm{d}}
---

# Álgebras de Lie semisimples

Los objetivos de esta sección son 2. Primero, escribir la idea general de un coset $G/H$. Y después hablar solo del álgebra de Lie de $G$.

### Cosets

Un manifold de la forma $$G/H$$ es homogéneo, dado que existe una acción de $G$ en $G/H$ que es transitiva. La relación de equivalencia del coset por la derecha es
$$
g_1 \sim g_2 \iff \exists  h \in H \text{ tal que } g_1 = g_2\cdot h 
$$
pensemos que las coordenadas son $(\phi) = (\phi^1, \dots, \phi^n)$ con $n=1,\dots, \dim G/H$. Entonces un representante del coset puede ser denotado por $L(\phi)$ entonces, tomando un $g \in G$, en general
$$
g \cdot L(\phi) = L(g*\phi) \cdot h(\phi, g), \qquad g \in G 
$$
La acción global de $G$ en el coset, en general resulta en otro coset representative, por lo que para llevarlo de vuelta a la parametrización $L(\phi)$ hay que considerar una *compensating tranformation* $h(\phi, g)$.

Para entender la idea de coset tenemos que definir el embedding de $H$ en $G$. Esto lo podemos hacer a nivel del álgebra de Lie, para la parte de $G$ conectada con la identidad.

El álgebra de ${\rm Lie}(G) = \mathbb{G}$ es un espacio vectorial con un producto bilineal antisimétrico (conmutador) y la identidad de Jacobi.

Vamos a descomponerlo en dos espacios ortogonales $$\mathbb{G} = \mathbb{H} \oplus \mathbb{K}$$ donde $\mathbb{K}$ es isomorfo al espacio tangente del coset $G/H$, en general **no es un álgebra de Lie**. Por otro lado $\mathbb{H}= {\rm Lie}(H)$ es el álgebra de lie del subgrupo $H$.

Las relaciones de conmutación son
$$
[\mathbb{H}, \mathbb{H}] \subset \mathbb{H} \, , \qquad [\mathbb{H}, \mathbb{K}] \subset \mathbb{K} \, , \qquad \qquad [\mathbb{K}, \mathbb{K}] \subset \mathbb{H} \oplus \mathbb{K} $$

- La primera relación dice que $\mathbb{H}$ es una subálgebra.
- La segunda dice que $\mathbb{K}$ soporta una representación de $H$ con respecto a su acción adjunta.
- La última dice que en general conmutadores entre $\mathbb{K}$ resultan en $\mathbb{G}$. Sin embargo, cuando $[\mathbb{K}, \mathbb{K}] \subset \mathbb{H}$ se dice que el manifold $G/H$ es *simétrico*.

La imagen que hay que tener en mente es que $G$ tiene una operación binaria interna.

### Álgebras semisimples

Pensemos ahora en $G$ solamente y su álgebra de Lie compleja $\mathbb{G}$. 

En una base dada del espacio vectorial $\{T_A\}$, el conmutador está completamente determinado por por las constantes de estructura
$$
    [T_A, T_B] = f_{AB}{}^{C}T_C
$$
Definimos el la forma de Killing, que es un bilineal simétrico $\kappa : \mathbb{G} \times \mathbb{G} \to \mathbb{C}$ como la traza en la adjunta
$$
    \kappa(X,Y) = \mathrm{Tr}_{\mathrm{ad}}(\mathrm{ad}_X \mathrm{ad}_y)= X^M Y^N f_{MA}{}^{B}f_{NB}{}^{A} \iff \kappa_{MN}=f_{MA}{}^{B}f_{NB}{}^{A}
$$
Pasa que podemos definir esto en cualquier representación, no solo en la fundamental. Entonces, en una representación $\mathsf{R}$ tenemos que
$$
    \mathrm{Tr}_{\mathsf{R}}(T_A T_B) = c_{\mathsf{R}}\kappa_{AB}
$$
donde $c_{\mathsf{R}}$ es una constante que depende de la representación. Cuento corto: $\kappa_{AB}$ es la métrica de Killing. Permite calcular normas en el álgebra.

> Una de las ideas en considerar el cosets es que la métrica del coset es la métrica de Killing inducida en la superficie.

> **Teorema** $\mathbb{G}$ es semisimple si y solo si la forma de Killing es no degenerada.

Definimos la subálgebra de Cartan (CSA) como la subálgebra abeliana maximal en $\mathbb{G}$.

> **Teorema:** Toda álgebra de Lie semisimple tiene una Cartan subálgebra.

Consideremos $\mathrm{CSA}\subset \mathbb{G}$ de un álgebra de Lie semisimple. Consideremos un elemento en su dual $\alpha \in \mathrm{CSA}^*$ que quiere decir es una aplicación lineal
$$
\alpha : \mathrm{CSA} \to \mathbb{C}
$$
Consideremos el siguiente subespacio
$$
    \mathbb{G}^{\alpha} = \{ X \in \mathbb{G} : [H,X]=\alpha(H) X, \forall H \in \mathrm{CSA}\}
$$
Consideremos una base de CSA $$\mathbf{CSA} = \mathrm{span}_{\mathbb{C}}(H_i:i=1,\dots,r)$$

- Si $\mathbb{G}^{\alpha} \neq \emptyset$ entonces decimos que $\alpha\in \mathrm{CSA}^*$ es una raíz (root) y $\mathbb{G}^{\alpha}$ es el subespacio correspondiente a la raíz $\alpha$.
- Ya que, por definición CSA es el abeliano maximal, entonces $\mathbb{G}^{0} = \mathrm{CSA}$
- De la identidad de Jacobi se sigue que [tarea]
$$
    [\mathbb{G}^{\alpha}, \mathbb{G}^{\beta}] \subset \mathbb{G}^{\alpha +\beta}
$$
Denotemos el conjunto de todas las raíces por $\Phi$. 

Los siguientes hechos son ciertos (Mirar el libro de Pietro Teorema 7.2.1):

- $\mathbb{G} = \bigoplus_{\alpha \in \Phi} \mathbb{G}^{\alpha} \oplus \mathrm{CSA}$
- $\dim(\mathbb{G}^{\alpha})=1, \forall \alpha \in \Phi$
- Si $\alpha$ es una raíz entonces $-\alpha$ también lo es.

> **Hecho importante:** Para una álgebra semisimple el espacio $\mathrm{span}_{\mathbb{R}}(\Phi)$ existe una forma simétrica que definida positiva: Para $\alpha \in \mathrm{span}_{\mathbb{R}}(\Phi)$
$$
    \kappa_\mathbb{R}(\alpha, \alpha)>0 \qquad \wedge \qquad \kappa_{\mathbb{R}}(\alpha, \alpha)=0 \implies \alpha=0
$$
> Esto significa que podemos representar las raíces como vectores en un espacio vectorial real de dimensión $r$.

**Hecho:** Es posible encontrar una base con la siguiente normalización
\begin{align*}
\kappa(H_i, H_j) = \delta_{ij}\\
\kappa(E^{\alpha}, E^{-\alpha})=1\\
\kappa(H_i, E^{\alpha})=0
\end{align*}
En lo que sigue vemos que la métrica restringida a la CSA es la delta. También lo es en su dual CSA$^*$. En particular en CSA$^*$ consideramos $(\alpha, \beta) = \alpha_i \beta_j \delta^{ij}$ De forma general podemos escribir los conmutadores como
\begin{align*}
[H_i, H_j]&=0 \\
[H_i, E^{\alpha}] &= \alpha(i) E^{\alpha} \\
[E^{\alpha}, E^{-\alpha}] &= \sum_i\alpha(i) H_i \\
[E^{\alpha}, E^{\beta}] &= \begin{cases} 
  N(\alpha, \beta) E^{\alpha + \beta} & \text{si } \alpha + \beta \in \Phi\\
  0 & \text{si } \alpha + \beta \notin \Phi
\end{cases}
\end{align*}

Algunos hechos del sistema de raíces

- $\frac{2(\alpha, \beta)}{(\alpha,\alpha)} \in \mathbb{Z}$
- $\sigma_\alpha(\beta) \equiv \beta - 2 \alpha \frac{(\alpha, \beta)}{(\alpha, \alpha)} \in \Phi$

La segunda corresponde a una reflexión de $\alpha$ respecto de $\beta$.

**Comentario:** Es posible definir un sistema de raíces para sí mismo
2. Si $\alpha \in \Phi$ el único múltiplo de $\alpha$ contenido en $\Phi$ son $\pm \alpha$
3. y 4. son los hechos anteriores.

**Definition: **Dado un sistema de raíces $\Phi \subset \mathbb{R}^r$. El conjunto $\Delta$ que contiene *exactamente* $r$ raíces es llamado base de raíces simples si:

1. $\Delta$ expande $\mathbb{R}^r$
2. Cada raíz $\alpha\in \Phi$ puede ser escrita como
$$
\alpha = \sum_{i=1}^r n^i \alpha_i \text{ o como }\alpha = - \sum_{i=1}^r n^i \alpha_i 
$$
con $n_i\in {0,1,2,\dots}$ pero no todos cero  a la vez. 

**Teorema: ** Todo sistema de raíces admite una base de raíces simples.

La demostración es constructiva. Y permite obtener el sistema de raíces simples, dado $\Phi$. El primer paso es convencerse que existe un splitting de las raíces en raíces positivas y negativas
$$
\Phi = \Phi_+ \cup \Phi_-
$$
(Siempre existe un plano $\Pi$ que que permite tener la mitad de las raíces a un lado y la otra mitad al otro.) En el día a día uno puede implementar esto fácilmente definiendo las raíces positivas como aquellas raíces cuya primera entrada no nula es positiva.

**Definición: ** Una raíz positiva se dice *simple* si **no** se puede escribir como suma de dos raíces positivas.

Las raíces simples son el corazón de la clasificación. 

Denotemos $\Delta = \{\alpha_1, \alpha_2, \dots, \alpha_r\}$ el conjunto de raíces simples. 

La matriz de Cartan definida como
$$
C_{ij} = 2 \frac{(\alpha_i, \alpha_j)}{(\alpha_j, \alpha_j)} \qquad \text{sin suma!}
$$

La matriz de Cartan se puede representar con un diagrama llamado diagrama de Dynkin (observe que los elementos de la diagonal son $2$).

Definamos la cantidad
$$
n_{ij} = C_{ij}C_{ji} <4 \qquad \text{sin suma!}
$$
Ya que esta cantidad está acotada **NO** todos los posibles enteros en las entradas $C_{ij}$ están permitidos. De hecho solo $\{-3, -2, -1, 0, 1, 2,3\}$

**Construcción del diagrama de Dynkin: **

1. Por cada raíz simple $\alpha_i$ dibuja un círculo.
2. Por cada par para de círculos, dibujo el número $n_{ij}$ de líneas uniéndolos.
3. Si hay 2 o 3 líneas entonces indica que raíz tiene módulo más grande con una flecha.

El teorema de clasificación dice que toda álgebra semisimple compleja se puede reconstruir del conjunto de raíces simples. Y estas solo puede ser de las formas siguiente:

![dynkin de las series e f g](/home/marcelo/Dropbox/2026_lectures/kk-udec/md/img/dynkin_abcd.png){ width=5cm }

- $\mathcal{A}_l \sim \mathfrak{sl}(l+1, \mathbb{C})$
- $\mathcal{B}_l \sim \mathfrak{so}(2l+1, \mathbb{C})$
- $\mathcal{D}_l \sim \mathfrak{so}(2l, \mathbb{C})$
- $\mathcal{C}_l \sim \mathfrak{sp}(2l, \mathbb{C})$

Se pueden ver isomorfismos simples.

Las álgebras de Lie excepcionales tiene diagrama de Dynkin

![dynkin de las series e f g](/home/marcelo/Dropbox/2026_lectures/kk-udec/md/img/dynkin_efg.png){ width=5cm }

## Secciones reales

Tal como hemos discutido, la clasificación es para álgebras semisimples complejas. Dada el álgebra de Lie en una sección la base de Cartan-Weyl $$T_A = \{ H_i, E^{\alpha}, E^{-\alpha} \}$$ Ahora vamos a introducir dos secciones reales que son universales para toda álgebra de Lie simple:

- *Maximally split real section* $\mathbb{G}_{\mathrm{max}}$ definida con coeficientes reales
$$
    \mathrm{span}_{\mathbb{R}}(H_i, E^{\alpha}, E^{-\alpha})
$$
- *Maximally compact real section* $\mathbb{G}_{\mathrm{c}}$ es definida por las siguientes matrices antihermíticas
$$
    \mathrm{span}_{\mathbb{R}}\{ i H_i, i(E^{\alpha} + E^{-\alpha}), E^{\alpha} - E^{-\alpha} \}
$$

## Ejemplo SL(3, C)
Consideremos un ejemplo para aterrizar las ideas. Consideramos el grupo $G=SL(3, \mathbb{C})$ cuya álgebra de Lie es $\mathfrak{sl}_3(\mathbb{C})$. El álgebra es el espacio vectorial tangente al origen:
$$
M\in SL(3) \implies \mathrm{det}(M)=1 \implies \mathrm{det}[e^{m}] = 1 \implies \mathrm{Tr}(m)=0
$$
El álgebra son las matrices sin traza.

Definamos el coeficiente de matriz $\epsilon_{i,j}$ como la matriz de 3 por 3 con entradas no nula en i,j e igual a uno.
\begin{align}
    \epsilon_{1,2} \quad
    \epsilon_{1,3} \quad
    \epsilon_{2,3} \\
    \epsilon_{2,1} \quad
    \epsilon_{3,1} \quad
    \epsilon_{3,2} \\
    \epsilon_{1,1}-\epsilon_{3,3} \\
    \epsilon_{2,2}-\epsilon_{3,3} \\
\end{align}
Note que $\mathrm{Tr}(\epsilon_{i,j})= \delta_{i,j}$.

Vamos al Mathematica y volvemos.
```Mathematica

CloseG[Xdni_]:=Module[
    {dx, Fdndnij, Xupi,productXXij, commutatorXXij, CdndnUpijk, CtimesX},
    dx = Length[Xdni];
	Fdndnij = Activate[TensorContract[Inactive[TensorProduct][Xdni,Xdni],{{3,6},{2,5}}]];
	Xupi = Inverse[Fdndnij] . Xdni;
	productXXij = Activate[TensorContract[Inactive[TensorProduct][Xdni,Xdni],{{3,5}}]];
    productXXij = Transpose[productXXij,{1,3,2,4}];
	commutatorXXij = productXXij-Transpose[productXXij,{2,1,3,4}];
	CdndnUpijk = Activate[TensorContract[Inactive[TensorProduct][commutatorXXij,Xupi],{{3,6},{4,7}}]];
	CtimesX = CdndnUpijk . Xdni;
	Return[Factor[commutatorXXij-CtimesX]===0*CtimesX]
];


com[x_,y_] := x . y-y . x;


KillingForm[gens_] := Table[Tr[h1 . h2],{h1, gens}, {h2, gens}];


Clear[GetRoots, GetRootsBundle];


GetRoots[cartan_, nocartan_] := Module[
	{ZZ, map, zeromat=ConstantArray[0, Length[cartan]]}, 
	map = Table[
				Position[nocartan, tIter][[1,1]] -> 
					Table[ZZ/.Solve[com[cIter, tIter]==ZZ*tIter][[1]], {cIter, cartan}]
			, {tIter, nocartan}];
	map = DeleteCases[map, zeromat];
	Return[Association[map]];
];


GetRootsBundle[rootsAsso_] := Module[
	{allPosibleSums, simpleroots, positiveroots, negativeroots, roots},
	roots = Values[rootsAsso];
	positiveroots = Select[roots, DeleteCases[#, 0][[1]]>0&];
	negativeroots = Complement[roots, positiveroots];
	
	allPosibleSums = Simplify[Map[Apply[Plus, #]&, Tuples[{positiveroots,positiveroots}]]];
	simpleroots = Complement[positiveroots, Intersection[allPosibleSums, positiveroots]];
	Return[<|"all"-> rootsAsso, 
	         "positive" -> Select[rootsAsso, MemberQ[positiveroots, #]&],
	         "simple" -> Select[rootsAsso, MemberQ[simpleroots, #]&],
	         "negative" -> Select[rootsAsso, MemberQ[negativeroots, #]&]|>];
];


```
---

Lo que hemos hecho es usar la descomposición de Iwasawa permite escribir el grupo como el siguiente producto
$$
     SL(3)=N_+AH, \qquad H= SO(3), \quad A= \exp(\mathrm{CSA}), \quad N=\exp(\mathrm{nilpotent}_+)
$$
Entonces si queremos parametrizar el coset 
$$
L = e^{x_1 E^{\alpha_1}}e^{x_2 E^{\alpha_2}}e^{x_{12} E^{\alpha_1+\alpha_2}} e^{s_1 H_1 + s_2 H_2}
$$
Es una matriz triangular superior que permite escribir un representante del coset que parametriza la Solvable Lie algebra que está en $\mathfrak{sl}_3$. Luego definimos una matriz que es independiente del compensador

Lo que hemos mostrado es que $$SL(3, \mathbb{R})/SO(3)$$ es espacio de dimensión 5 euclídeo que es Einstein
$$
R^{i}{}_{j} = -3 \delta^{i}_{j} \implies R = -15
$$


# Conteo de 11 a 4

Ya que vieron una reducción dimensional desde 10D a 4D en un **toro** de super-Yang-Mills. Podemos considerar la reducción de un $T^7$ desde *11D supergravity*.

- Contenido de campos en 11D: $g_{\hat \mu \hat \nu}, A_3, \Psi^{\alpha}_{\hat \mu}$
- Separación de índices $\hat \mu \in \{\mu, i\}$

> **Breve nota:** La dimensión D=11 es la máxima dimensión que permite tener campos de spin 2. Si uno va a más dimensiones, entonces el álgebra de supersimetría requiere incluir campos con spin > 2.
>
> Históricamente, la teoría en D=11 fue construida/descubierta en 1978 por Eugène Cremmer, Bernard Julia, and Joël Scherk.
>
> En 1982 Bernard De Wit y Herman Nicolai construyeron la teoría maximal $\mathcal{N}=8, D=4$ gauged con grupo de gauge $SO(8)$.
>
> En 1987 ellos mostraron que la reducción dimensional de la teoría en $D=11$ es consistente truncar a los modos sin masa y además mostraron que la teoría resultante es la misma que la $D=4, \mathcal{N}=8$, que construyeron 5 años antes.

En esta clase vamos a considerar el conteo de campos de la teoría en $D=11$, en un 7-toro. 

## Conteo de campos
Vamos a ver la métrica, la 3-forma y los fermiones.

### Métrica

En la reducción genérica consideramos la forma de métrica
\begin{equation}
    ds^2 = g_{\mu \nu} \dd x^\mu \dd x^\nu + h_{ij}(\dd y^i + \mathcal{A}^i)(\dd y^j + \mathcal{A}^j)
\end{equation}
Podemos definir a 1-form $V^i = \dd y^i + \mathcal{A}^i$, donde los vectores $$ \mathcal{A}^i = \mathcal{A}^i {}_{\mu} \dd x^\mu $$ son 1-formas en $M_4$.
\begin{align*}
g_{i j} \qquad 28 \text{ escalares} \\
g_{\mu i} \qquad 7 \text{ vectores} \\
g_{\mu \nu} \qquad 1 \text{ métrica}
\end{align*}

### 3-forma

De la 3-form vienen podemos hacer la separación
\begin{align}
    \hat{A}_3 = A_3 + A_{2i} V^i + \frac12 A_{1ij} V^i \wedge V^j + \frac{1}{3!}A_{ijk}V^i \wedge V^j \wedge V^k 
\end{align}
Entonces, vemos que hay

- una sola 3-forma $A_3$, que **NO es propagante** en $D=4$.
- $A_{2i}$, son 7 2-formas.
- $A_{1ij}$ son 21 vectores.
- $A_{ijk}$ son $7 \cdot 6 \cdot 5/3! = 7\cdot 5 = 35$ escalares.

Cuántos escalares hay? Sin hacer nada hay $35 + 28 = 63$.

**Faltan 7 escalares!** Estos vienen de dualizar las 2-formas en $D=4$. La idea es
\begin{equation*} 
   A_2  \qquad \to \qquad F_3 = \dd A_2 \qquad \to \qquad\star F_3 = F_1 \qquad \to\qquad F_1 = \dd C_0
\end{equation*}

Entonces consideramos, ya que tenemos $7$ 2-formas, si las dualizamos, entonces tendremos $7$ escalares más que dan lugar a los 70 escalares reales. De la $\mathcal{N}=8$ en $D=4$.

---

#### Cómo se dualiza?
>Imagina que ya hiciste la reducción y te quedó un término del estilo (considera $\star$ en 4D)
>$$\mathbf{L}_{4,F_3}[C_2] = -\dd C_2 \wedge \star \dd C_2$$
>Para dualizar, hagamos lo siguiente: vamos a introducir un multiplicador de Lagrange $\check{F}_3$ 
>\begin{align}
>    \tilde{\mathbf{L}}[\check{F}_3, C_0] = -\check{F}_3 \wedge \star \check{F}_3 + \check{F}_3 \wedge \dd C_0
>\end{align}
>Si variamos respecto de $C_0$ nos queda que $\dd \check{F}_3=0$, o sea $\check{F}_3 = \dd C_2$
Reemplazamos de vuelta y obtenemos el lagrangiano sin tilde, módulo un término de borde.

> Si variamos respecto de $\check{F}_3$ nos queda que $\star \check{F}_3 = \frac12 \dd C_0$


>> **Identidad:** El dual de Hodge al cuadrado es $\star^2 F_p = (-1)^{p(D-p) + 1} F_p$ en un espacio lorentziano con un tiempo.

> Entonces $\check{F}_3= \frac12 \star \dd C_0$. Reemplazamos nuestro descubrimiento en el lagrangiano tilde
> \begin{align}
>   \tilde{L} =\dots = - \frac12 \dd C_0 \wedge \star \dd C_0 \, .
>\end{align}
> Con el signo correcto!

### Fermiones

La historia con los fermiones comienza siempre con definir el álgebra de Clifford
$$
\{ \hat{\Gamma}^{\hat{a}} , \hat{\Gamma}^{\hat{b}} \} = 2 \eta^{\hat{a} \hat{b}} \mathbf{1}
$$
La pregunta es: cuál es la dimensión de las $D$ matrices $\Gamma^{\hat{b}}$, que satisfacen esta relación de anticonmutación?

|$D$ | $\mathrm{dim}(\hat{\Gamma}^{\hat{a}})$|
|----|---------------------------------------|
| 2  |                 2                     |
| 3  |                 2                     |
| 4  |                 4                     |
| 5  |                 4                     |
| 6  |                 8                     |
| 7  |                 8                     |
| 8  |                 16                    |
| 9  |                 16                    |
| 10 |                 32                    |
| 11 |                 32                    |
| 12 |                 64                    |
La dimensión es $2$ a la parte entera de $D/2$.

Entonces en dimensión $11$, pasa que los espinores tiene $32$ componentes. Las cuales pueden ser complejas en general. Sin embargo, los espinores de [**check**] la teoría son Majorana. Entonces son 32 componentes reales.

El spinor transforma en la representación $\mathbf{32}$ of Spin(1, 10).

Dado la separación del espacio tiempo en una de dimensión 4 y otro de dimensión 7, el spinor se separa respetando esto como $\mathbf{32} \to \mathbf{4} \otimes \mathbf{8}$ donde $\mathbf{4}$ es de Spin(1,3) y $\mathbf{8}$ es de Spin(7).

>> **Comentario 1:** $SO(n)$ con $n>2$ *no es simplemente conexo*. De hecho $\pi_1(SO(n))= \mathbb{Z}_2$ para $n>2$.

>> **Comentario 2:** Spin(n) es simplemente conexo y existe un mapeo 2 a 1 Spin(n)$\to$ SO(n). Entonces Spin(n) coincide con el cubrimiento universal de SO(n).

Esto implica que el spinor, por un lado, los índices de espacio tiempo se separan como los de los otros campos $$
\Psi_{\hat\mu}^{\hat \alpha} \to \Psi_{\mu}^{\hat \alpha}, \quad \Psi_{i}^{\hat \alpha}
$$
Mientras que los índices spinoriales se separan como
$$
\hat{\alpha} \to (\alpha, A)
$$
donde $\alpha=1,\dots, 4$ y $A=1,\dots, 8$. 

Por lo tanto, 

- $\Psi_{i}^{\hat \alpha}\to \Psi_{i}^{\alpha A}$, son $56$ spinores de Majorana de spin 1/2.
- $\Psi_{\mu}^{\hat \alpha}\to \Psi_{\mu}^{\alpha A}$ son 8 spinores de Majorana de spin 3/2.

Observe que estos campos se puede organizar en representaciones de $SU(8)$, siendo la $\mathbf{8}$ la fundamental de $SU(8)$ y la $\mathbf{56}$ la 3 veces antisimétrica:

$$
\Psi_i{}^{A} \to \text{reempaquetamiento en SU(8)} \to  \chi^{ABC}
$$

## Manifold escalar
El número 70 no es accidental. En la teoría maximal en D=4, los
escalares parametrizan la variedad homogénea

$$
M_{\rm scalar}=\frac{E_{7(7)}}{SU(8)}.
$$

En efecto,

$$
\dim E_{7(7)}-\dim SU(8)=133-63=70.
$$


El grupo SU(8) es el grupo local de isotropía del coset. Por eso la
formulación $D=4, \mathcal{N}=8$ organiza los campos usando índices
SU(8):

$$
\psi_\mu^A,\qquad
A_\mu^{AB}=A_\mu^{[AB]},\qquad
\chi^{ABC}=\chi^{[ABC]},\qquad
\phi^{ABCD}=\phi^{[ABCD]}.
$$

>> Para entender la notación de coset es preciso introducir un poco de lenguaje sobre álgebras de Lie.

De forma más genérica la reducción es


![Reducciones dimensiones desde D=11 en un n-toro](/home/marcelo/Dropbox/2026_lectures/kk-udec/md/img/all_kaluza_klein.png){ width=8cm }

